import React, { useState, useEffect, useRef } from 'react';
import { 
  Home, 
  ArrowLeft, 
  RefreshCw, 
  Star, 
  Clock, 
  Shield, 
  ShieldOff, 
  Globe,
  AlertTriangle,
  Menu
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const DEFAULT_URL = 'https://en.wikipedia.org/wiki/Main_Page';

export default function App() {
  const [url, setUrl] = useState(DEFAULT_URL);
  const [inputUrl, setInputUrl] = useState(DEFAULT_URL);
  const [history, setHistory] = useState<string[]>([DEFAULT_URL]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [adBlockEnabled, setAdBlockEnabled] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const navigateTo = (newUrl: string) => {
    let finalUrl = newUrl.trim();
    if (!finalUrl) return;
    
    // Auto-prepend https if not present and not a valid URL format (simple check)
    if (!/^https?:\/\//i.test(finalUrl)) {
      if (finalUrl.includes('.') && !finalUrl.includes(' ')) {
        finalUrl = 'https://' + finalUrl;
      } else {
        // Treat as search query
        finalUrl = 'https://bing.com/search?q=' + encodeURIComponent(finalUrl);
      }
    }

    setUrl(finalUrl);
    setInputUrl(finalUrl);
    
    // Update history
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(finalUrl);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    setIsLoading(true);
  };

  const handleGo = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    navigateTo(inputUrl);
  };

  const handleBack = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      const prevUrl = history[newIndex];
      setUrl(prevUrl);
      setInputUrl(prevUrl);
      setIsLoading(true);
    }
  };

  const handleRefresh = () => {
    setIsLoading(true);
    if (iframeRef.current) {
      // To force reload the iframe, we can temporarily set it to empty or re-assign src
      // Since react might not re-render if src is the same, we can use a trick
      const currentSrc = url;
      setUrl('');
      setTimeout(() => setUrl(currentSrc), 10);
    }
  };

  const handleHome = () => {
    navigateTo(DEFAULT_URL);
  };

  const toggleBookmark = () => {
    if (bookmarks.includes(url)) {
      setBookmarks(bookmarks.filter(b => b !== url));
    } else {
      setBookmarks([...bookmarks, url]);
    }
  };

  // IFrame loading handler
  useEffect(() => {
    const handleLoad = () => setIsLoading(false);
    const iframe = iframeRef.current;
    if (iframe) {
      iframe.addEventListener('load', handleLoad);
      return () => iframe.removeEventListener('load', handleLoad);
    }
  }, [url]);

  // Handle iframe load event directly on the element as fallback
  const onIframeLoad = () => {
    setIsLoading(false);
  };

  // Determine sandbox attributes based on adBlockEnabled
  // If adBlock is enabled, we might restrict popups and certain scripts if possible,
  // but restricting scripts breaks most modern sites.
  // Instead, we can restrict popups to prevent popup ads.
  const sandboxProps = adBlockEnabled 
    ? "allow-same-origin allow-scripts allow-forms" // Removed allow-popups
    : "allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox";

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans relative">
      {/* Background decoration */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-cyan-600/20 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Navigation Bar (Glassmorphism) */}
      <header className="relative z-10 flex items-center justify-between px-4 py-3 bg-slate-900/60 backdrop-blur-xl border-b border-slate-700/50 shadow-lg">
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-lg hover:bg-slate-800/80 transition-colors text-slate-300 hover:text-white"
            title="Toggle Sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div className="flex items-center space-x-1 ml-2 bg-slate-800/50 rounded-lg p-1 border border-slate-700/50">
            <button 
              onClick={handleBack} 
              disabled={historyIndex <= 0}
              className={cn(
                "p-1.5 rounded-md transition-colors",
                historyIndex > 0 ? "hover:bg-slate-700 text-slate-200" : "text-slate-600 cursor-not-allowed"
              )}
              title="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <button 
              onClick={handleRefresh}
              className="p-1.5 rounded-md hover:bg-slate-700 text-slate-200 transition-colors"
              title="Refresh"
            >
              <RefreshCw className={cn("w-4 h-4", isLoading && "animate-spin")} />
            </button>
            <button 
              onClick={handleHome}
              className="p-1.5 rounded-md hover:bg-slate-700 text-slate-200 transition-colors"
              title="Home"
            >
              <Home className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* URL Bar */}
        <form 
          onSubmit={handleGo} 
          className="flex-1 max-w-3xl mx-4 flex items-center bg-slate-800/60 border border-slate-700/50 rounded-full px-4 py-1.5 focus-within:ring-2 focus-within:ring-indigo-500/50 focus-within:border-indigo-500/50 transition-all shadow-inner"
        >
          <Globe className="w-4 h-4 text-slate-400 mr-2 flex-shrink-0" />
          <input
            type="text"
            value={inputUrl}
            onChange={(e) => setInputUrl(e.target.value)}
            className="flex-1 bg-transparent border-none outline-none text-sm text-slate-200 placeholder-slate-500"
            placeholder="Search or enter web address"
          />
          <button 
            type="submit"
            className="ml-2 px-3 py-1 bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/40 border border-indigo-500/30 rounded-full text-xs font-semibold transition-colors"
          >
            Go
          </button>
          <div className="w-px h-4 bg-slate-700 mx-2" />
          <button 
            type="button"
            onClick={toggleBookmark}
            className="p-1 text-slate-400 hover:text-yellow-400 transition-colors"
            title={bookmarks.includes(url) ? "Remove Bookmark" : "Add Bookmark"}
          >
            <Star className={cn("w-4 h-4", bookmarks.includes(url) && "fill-yellow-400 text-yellow-400")} />
          </button>
        </form>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setAdBlockEnabled(!adBlockEnabled)}
            className={cn(
              "flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all",
              adBlockEnabled 
                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20" 
                : "bg-slate-800/50 text-slate-400 border-slate-700/50 hover:bg-slate-700"
            )}
            title="Toggle Ad-Block (Restricts Popups)"
          >
            {adBlockEnabled ? <Shield className="w-3.5 h-3.5" /> : <ShieldOff className="w-3.5 h-3.5" />}
            <span>{adBlockEnabled ? 'Shield On' : 'Shield Off'}</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden relative z-10">
        
        {/* Sidebar */}
        <aside 
          className={cn(
            "flex flex-col bg-slate-900/40 backdrop-blur-md border-r border-slate-700/50 transition-all duration-300 ease-in-out z-20",
            sidebarOpen ? "w-64 opacity-100" : "w-0 opacity-0 overflow-hidden border-none"
          )}
        >
          <div className="p-4 flex-1 overflow-y-auto custom-scrollbar flex flex-col gap-6 w-64">
            
            {/* Bookmarks */}
            <div>
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3 flex items-center">
                <Star className="w-3.5 h-3.5 mr-2" />
                Bookmarks
              </h3>
              {bookmarks.length === 0 ? (
                <p className="text-sm text-slate-600 italic px-2">No bookmarks yet</p>
              ) : (
                <ul className="space-y-1">
                  {bookmarks.map((b, i) => (
                    <li key={i}>
                      <button 
                        onClick={() => navigateTo(b)}
                        className="w-full text-left px-2 py-1.5 rounded-md hover:bg-slate-800/60 text-sm text-slate-300 truncate transition-colors"
                        title={b}
                      >
                        {b.replace(/^https?:\/\//, '').split('/')[0]}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* History */}
            <div>
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3 flex items-center">
                <Clock className="w-3.5 h-3.5 mr-2" />
                History
              </h3>
              <ul className="space-y-1">
                {/* Show last 10 history items */}
                {history.slice().reverse().slice(0, 10).map((h, i) => (
                  <li key={i}>
                    <button 
                      onClick={() => navigateTo(h)}
                      className="w-full text-left px-2 py-1.5 rounded-md hover:bg-slate-800/60 text-sm text-slate-400 truncate transition-colors"
                      title={h}
                    >
                      {h.replace(/^https?:\/\//, '').split('/')[0]}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            
          </div>
          
          <div className="p-4 border-t border-slate-700/50 bg-slate-900/50 w-64">
            <div className="flex items-start space-x-2 text-xs text-amber-500/80 bg-amber-500/10 p-2 rounded-lg border border-amber-500/20">
              <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <p>Some major sites block framing. Try searching on Bing instead.</p>
            </div>
          </div>
        </aside>

        {/* Browser Content */}
        <main className="flex-1 relative bg-white">
          {isLoading && (
            <div className="absolute inset-0 bg-slate-950/20 backdrop-blur-sm z-20 flex flex-col items-center justify-center">
              <div className="w-12 h-12 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin"></div>
              <p className="mt-4 text-sm font-medium text-slate-200 shadow-sm">Loading...</p>
            </div>
          )}
          
          {url ? (
            <iframe
              ref={iframeRef}
              src={url}
              className="w-full h-full border-none bg-white"
              sandbox={sandboxProps}
              onLoad={onIframeLoad}
              title="Browser Content"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-slate-900 text-slate-500">
              <p>Enter a URL to browse</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
